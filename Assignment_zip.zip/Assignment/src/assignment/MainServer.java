package assignment;
public class MainServer 
{ 
    public static void main(String [] args) 
    { 
        Server nishpa_999=new Server(); 
        Thread t_nishpa=new Thread( nishpa_999); 
        t_nishpa.start(); 
        //creation of thread for server class
    } 
}