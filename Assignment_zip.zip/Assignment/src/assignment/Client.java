package assignment;
import java.io.DataInputStream; 
import java.io.DataOutputStream; 
import java.io.EOFException; 
import java.io.IOException;
import java.net.Socket; 
import java.util.Scanner;
 
public class Client implements Runnable 
{ 
@Override 
public void run() 
{ 
    try 
        { 
            //connecting the socket 
            Socket st=new Socket("localhost",7691); 
            Scanner sc=new Scanner(System.in); 
            //telling the user to put in their civilid
            System.out.println("Enter your civil ID"); 
            //accepting their id
            int id=sc.nextInt(); 
            //telling them to choose an option
            System.out.println("Select which option you want? 1(Monthly) 2(Half-yearly) 3(Yearly)");
            //accepting their input
            int opt=sc.nextInt();
            
            //sending to the server
            DataOutputStream dos=new DataOutputStream(st.getOutputStream()); 
            dos.writeInt(id); 
            dos.writeInt(opt);
            dos.flush(); 
            
            //reciving from the server
            DataInputStream dis=new DataInputStream(st.getInputStream()); 
            try 
            { 
            //recieving from the server
            String bd= dis.readUTF();
            double totalprice=dis.readDouble();
            double discountprice= dis.readDouble();
            double ftp=dis.readDouble();
            
            //sending it to the users
            System.out.println("Your booking duration is for "+bd); 
            System.out.println("Calculated Price is: " + totalprice);
            System.out.println("You have "+discountprice);
            System.out.println("Your final ticket price is "+ftp);
            
            //closing
            dis.close();
            dos.close();
            st.close();
            
            
            } 
            catch(EOFException e) 
            { 
             System.out.println("Record not found on the database table");    
            } 
        } 
        catch(IOException e) 
        { 
            System.out.println(e); 
        } 
    } 
}
