package assignment;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Server implements Runnable   
{ 
    @Override 
    public void run() 
    {     
      try 
        { 
            //connecting with database
            String host = "jdbc:derby://localhost:1527/assignmentMwasalat"; 
            String un="nishpadas"; 
            String pass="123456789"; 
            Connection con = DriverManager.getConnection(host,un,pass); 
            ServerSocket ss = new ServerSocket(7691); 
            System.out.println("connection is ready");
            while(true) 
            { 
                 //accepting the client connection  
                 Socket st = ss.accept(); 
                //receive data from client  
                 DataInputStream dis = new  DataInputStream(st.getInputStream()); 
                 int id = dis.readInt(); 
                 int opt= dis.readInt();
                 //sending the results  
                 //finding the option from the database 
                 Statement smt = con.createStatement();  //initiating SQL command
                 
                 String getvals = ("select * from NISHPADAS where CHOICE=" +opt); //searching for the choice
                 smt.execute(getvals); //recieving output from the database
                 ResultSet rs = smt.getResultSet(); //saving the output in the results
                 
                 
                 DataOutputStream dos = new DataOutputStream(st.getOutputStream());   
                 double ticketprice=0.3;
                 if(rs.next()) {
 
                     
                    String bd = rs.getString("BOOKINGDURATION"); 
                    System.out.println(bd);
                    double discount= rs.getDouble("DISCOUNT");
                    System.out.println(discount);
                    double d;
                    
                        if(bd.equals("Monthly")) {
                             d=30;
                        }
                        else if(bd.equals("Half Yearly")) {
                             d=180;
                        }
                        else
                        {
                             d=365;
                            
                        }
                        
                    double totalprice= ticketprice*d;
                    double discountprice=totalprice*discount;
                    double ftp=totalprice-discountprice;
                    
                    //sending off the data to client
                    dos.writeUTF(bd);
                    dos.writeDouble(totalprice);
                    dos.writeDouble(discountprice);
                    dos.writeDouble(ftp);
                    dos.flush();
                    
                 }
                   else  
                  { 
                    dos.writeInt(opt); 
                     System.out.println("option not found in the table " + opt); 
                  } 
                 
                   //closing

                   dos.close();
                   dis.close();
                   st.close();
                   
                } 
           } 
         catch(IOException ex) 
         { 
            System.out.print(ex); 
         } catch (SQLException ex) { 
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex); 
        } 
    } 
}    
 