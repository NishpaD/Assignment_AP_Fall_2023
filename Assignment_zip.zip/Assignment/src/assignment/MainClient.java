//import of package
package assignment;
public class MainClient  
{ 
    public static void main(String [] args) 
    { 
        Client nishpa_999=new Client(); 
        Thread t_nishpa=new Thread( nishpa_999); 
      t_nishpa.start(); 
      //creation of thread for the client class
    } 
} 